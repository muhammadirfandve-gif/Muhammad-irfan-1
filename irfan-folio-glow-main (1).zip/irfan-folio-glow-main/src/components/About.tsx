import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import profileImage from "@/assets/profile.png";

gsap.registerPlugin(ScrollTrigger);

const About = () => {
  const aboutRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".about-image", {
        opacity: 0,
        x: -100,
        duration: 1,
        scrollTrigger: {
          trigger: ".about-image",
          start: "top 80%",
        },
      });
      
      gsap.from(".about-content", {
        opacity: 0,
        x: 100,
        duration: 1,
        scrollTrigger: {
          trigger: ".about-content",
          start: "top 80%",
        },
      });
      
      gsap.from(".skill-item", {
        opacity: 0,
        scale: 0.8,
        duration: 0.5,
        stagger: 0.1,
        scrollTrigger: {
          trigger: ".skills-grid",
          start: "top 80%",
        },
      });
    }, aboutRef);

    return () => ctx.revert();
  }, []);

  const skills = [
    "Shopify Theme",
    "Liquid Coding",
    "WordPress",
    "Elementor Pro",
    "Speed Optimization",
    "Responsive Design",
    "Bug Fixing",
    "On-Page SEO",
    "Custom Integrations",
    "HTML/CSS",
    "JavaScript",
    "React",
  ];

  return (
    <section
      ref={aboutRef}
      className="py-20 px-4 relative overflow-hidden"
      id="about"
    >
      <div className="absolute inset-0 grid-bg opacity-10" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
          <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            About Me
          </span>
        </h2>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Profile Image */}
          <div className="about-image flex justify-center">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-br from-primary to-secondary rounded-full blur-2xl opacity-30 group-hover:opacity-50 transition-opacity duration-500" />
              <img
                src={profileImage}
                alt="Muhammad Irfan"
                className="relative w-72 h-72 rounded-full object-cover border-4 border-primary/30 shadow-2xl transform group-hover:scale-105 transition-transform duration-500"
              />
            </div>
          </div>
          
          {/* About Content */}
          <div className="about-content space-y-6">
            <h3 className="text-2xl md:text-3xl font-bold">Muhammad Irfan</h3>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Shopify & WordPress Developer with 3 years of experience creating immersive web experiences.
              I specialize in custom theme development, speed optimization, and building responsive designs
              that convert visitors into customers.
            </p>
            
            <div className="space-y-2 text-muted-foreground">
              <p><span className="text-foreground font-semibold">Education:</span> Bachelor in Computer Science</p>
              <p><span className="text-foreground font-semibold">Experience:</span> 3 years (1 year at Smart Leading Solution)</p>
              <p><span className="text-foreground font-semibold">Email:</span> irfanonline37@gmail.com</p>
              <p><span className="text-foreground font-semibold">Phone:</span> +92 302 5849734</p>
            </div>
            
            {/* Skills */}
            <div className="skills-grid grid grid-cols-3 gap-3 pt-6">
              {skills.map((skill, index) => (
                <div
                  key={index}
                  className="skill-item glass-card px-4 py-2 text-center text-sm font-medium rounded-lg hover:glow-border transition-all duration-300 hover:scale-105"
                >
                  {skill}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
