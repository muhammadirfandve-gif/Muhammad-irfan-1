import { useEffect, useRef } from "react";
import { gsap } from "gsap";

const TechStack = () => {
  const trackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (trackRef.current) {
      gsap.to(trackRef.current, {
        xPercent: -50,
        duration: 20,
        repeat: -1,
        ease: "linear",
      });
    }
  }, []);

  const techIcons = [
    { name: "HTML5", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" },
    { name: "CSS3", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" },
    { name: "JavaScript", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" },
    { name: "React", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" },
    { name: "WordPress", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/wordpress/wordpress-original.svg" },
    { name: "Shopify", icon: "https://img.icons8.com/?size=100&id=uSHYbs6PJfMT&format=png&color=000000" },
    { name: "PHP", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg" },
    { name: "Git", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" },
    { name: "Figma", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg" },
    { name: "Photoshop", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/photoshop/photoshop-plain.svg" },
  ];

  return (
    <section className="py-20 px-4 relative overflow-hidden bg-gradient-to-b from-background via-space-navy to-background">
      <div className="absolute inset-0 grid-bg opacity-10" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
          <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent glow-text">
            Languages & Tools
          </span>
        </h2>
        
        <div className="relative overflow-hidden" style={{
          maskImage: "linear-gradient(to right, transparent, black 10%, black 90%, transparent)",
          WebkitMaskImage: "linear-gradient(to right, transparent, black 10%, black 90%, transparent)"
        }}>
          <div ref={trackRef} className="flex gap-10 items-center">
            {/* Render twice for seamless loop */}
            {[...techIcons, ...techIcons].map((tech, index) => (
              <div
                key={index}
                className="min-w-[130px] h-[130px] glass-card rounded-2xl flex items-center justify-center hover:scale-110 hover:glow-border transition-all duration-300 group"
              >
                <img
                  src={tech.icon}
                  alt={tech.name}
                  className="w-16 h-16 group-hover:drop-shadow-[0_0_10px_rgba(91,140,255,0.7)] transition-all duration-300"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TechStack;
