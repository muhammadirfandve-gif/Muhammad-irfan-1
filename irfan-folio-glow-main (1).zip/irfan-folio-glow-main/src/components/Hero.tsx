import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { Github } from "lucide-react";
import { Button } from "@/components/ui/button";

const Hero = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".hero-title", {
        opacity: 0,
        y: 50,
        duration: 1,
        ease: "power3.out",
      });
      
      gsap.from(".hero-subtitle", {
        opacity: 0,
        y: 30,
        duration: 1,
        delay: 0.3,
        ease: "power3.out",
      });
      
      gsap.from(".hero-cta", {
        opacity: 0,
        scale: 0.8,
        duration: 0.8,
        delay: 0.6,
        ease: "back.out(1.7)",
      });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      id="home"
    >
      {/* Spline 3D Background */}
      <div className="absolute inset-0 z-0">
        <iframe
          src="https://my.spline.design/orb-U18g7yz96jOtOdhQI1QVjWBm/"
          className="w-full h-full border-0"
          title="3D Background"
        />
      </div>
      
      {/* Grid Overlay */}
      <div className="absolute inset-0 grid-bg opacity-20 z-10" />
      
      {/* Content */}
      <div className="relative z-20 text-center px-4 max-w-4xl mx-auto">
        <h1 className="hero-title text-5xl md:text-7xl lg:text-8xl font-bold mb-6">
          <span className="glow-text">Hi, I'm</span>
          <br />
          <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Muhammad Irfan
          </span>
        </h1>
        
        <p className="hero-subtitle text-xl md:text-2xl text-muted-foreground mb-8">
          Shopify & WordPress Developer
        </p>
        
        <p className="hero-subtitle text-lg text-muted-foreground/80 mb-12 max-w-2xl mx-auto">
          I build immersive Shopify & WordPress experiences with modern design and seamless functionality.
        </p>
        
        <div className="hero-cta flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            size="lg"
            variant="hero"
            className="btn-shimmer"
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Hire Me
          </Button>
          
          <Button
            size="lg"
            variant="glass"
            onClick={() => window.open('https://github.com/irfanonline37', '_blank')}
          >
            <Github className="mr-2 h-5 w-5" />
            GitHub
          </Button>
        </div>
      </div>
      
      {/* Floating Orbs */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-primary/20 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-20 right-10 w-40 h-40 bg-secondary/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
    </section>
  );
};

export default Hero;
