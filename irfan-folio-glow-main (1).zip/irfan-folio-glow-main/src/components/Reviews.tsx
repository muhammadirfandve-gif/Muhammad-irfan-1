import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Star } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const Reviews = () => {
  const reviewsRef = useRef<HTMLDivElement>(null);

  const reviews = [
    {
      name: "Sarah Johnson",
      role: "Store Owner",
      rating: 5,
      comment: "Muhammad transformed our Shopify store completely. Sales increased by 40% after his optimizations!",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    },
    {
      name: "David Miller",
      role: "E-commerce Manager",
      rating: 5,
      comment: "Excellent work on custom theme development. Very professional and delivered ahead of schedule.",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    },
    {
      name: "Emma Wilson",
      role: "Business Owner",
      rating: 5,
      comment: "Outstanding speed optimization! Our page load time dropped from 8s to 2s. Highly recommend!",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    },
    {
      name: "Michael Brown",
      role: "Marketing Director",
      rating: 4,
      comment: "Great attention to detail and responsive design. Our mobile conversion rate doubled.",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    },
    {
      name: "Lisa Anderson",
      role: "Entrepreneur",
      rating: 5,
      comment: "Muhammad's Liquid coding skills are exceptional. He created custom features we thought were impossible.",
      avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop",
    },
    {
      name: "James Taylor",
      role: "Retail Manager",
      rating: 5,
      comment: "WordPress migration was seamless. Zero downtime and improved performance significantly.",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    },
    {
      name: "Rachel Green",
      role: "Brand Manager",
      rating: 5,
      comment: "Incredible design sense and technical expertise. Our brand identity really shines through now.",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
    },
    {
      name: "Tom Harris",
      role: "CEO",
      rating: 4,
      comment: "Solid developer with great communication. Fixed complex bugs that others couldn't solve.",
      avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".review-card", {
        opacity: 0,
        y: 50,
        duration: 0.6,
        stagger: 0.1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: ".reviews-grid",
          start: "top 70%",
        },
      });
    }, reviewsRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={reviewsRef}
      className="py-20 px-4 relative overflow-hidden"
      id="reviews"
    >
      <div className="absolute inset-0 grid-bg opacity-10" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
          <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Client Reviews
          </span>
        </h2>
        
        <div className="reviews-grid grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviews.map((review, index) => (
            <div
              key={index}
              className="review-card glass-card p-6 rounded-xl hover:scale-105 transition-all duration-500 hover:glow-border"
            >
              <div className="flex items-center gap-4 mb-4">
                <img
                  src={review.avatar}
                  alt={review.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-primary/30"
                />
                <div>
                  <h4 className="font-semibold">{review.name}</h4>
                  <p className="text-xs text-muted-foreground">{review.role}</p>
                </div>
              </div>
              
              <div className="flex gap-1 mb-3">
                {Array.from({ length: review.rating }).map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4 fill-primary text-primary"
                  />
                ))}
              </div>
              
              <p className="text-sm text-muted-foreground leading-relaxed">
                "{review.comment}"
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Reviews;
