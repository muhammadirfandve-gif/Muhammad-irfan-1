import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import emailjs from "@emailjs/browser";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Mail, Phone, Github } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const Contact = () => {
  const contactRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".contact-form", {
        opacity: 0,
        x: -50,
        duration: 1,
        scrollTrigger: {
          trigger: ".contact-form",
          start: "top 80%",
        },
      });
      
      gsap.from(".contact-info", {
        opacity: 0,
        x: 50,
        duration: 1,
        scrollTrigger: {
          trigger: ".contact-info",
          start: "top 80%",
        },
      });
    }, contactRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);

    try {
      await emailjs.sendForm(
        "service_zs3c55f",
        "template_lfisv5k",
        formRef.current!,
        "6lrk4U-oY50IGJoA_"
      );

      toast({
        title: "Message Sent!",
        description: "Thank you for reaching out. I'll get back to you soon!",
      });

      formRef.current?.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      ref={contactRef}
      className="py-20 px-4 relative overflow-hidden"
      id="contact"
    >
      <div className="absolute inset-0 grid-bg opacity-10" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
          <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Get In Touch
          </span>
        </h2>
        
        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="contact-form glass-card p-8 rounded-xl">
            <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Name</label>
                <Input
                  name="from_name"
                  required
                  placeholder="Your name"
                  className="bg-muted/50 border-primary/20 focus:border-primary"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Email</label>
                <Input
                  type="email"
                  name="from_email"
                  required
                  placeholder="your.email@example.com"
                  className="bg-muted/50 border-primary/20 focus:border-primary"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Message</label>
                <Textarea
                  name="message"
                  required
                  placeholder="Tell me about your project..."
                  rows={5}
                  className="bg-muted/50 border-primary/20 focus:border-primary resize-none"
                />
              </div>
              
              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-primary hover:bg-primary/90 glow-border transition-all duration-300 hover:scale-105"
                size="lg"
              >
                {loading ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </div>
          
          {/* Contact Info */}
          <div className="contact-info space-y-8">
            <div>
              <h3 className="text-2xl font-bold mb-6">Let's Work Together</h3>
              <p className="text-muted-foreground leading-relaxed">
                I'm currently available for freelance work and exciting projects. 
                Whether you need a custom Shopify theme, WordPress site, or help 
                optimizing your existing store, I'm here to help bring your vision to life.
              </p>
            </div>
            
            <div className="space-y-4">
              <a
                href="mailto:irfanonline37@gmail.com"
                className="flex items-center gap-4 p-4 glass-card rounded-lg hover:glow-border transition-all duration-300 hover:scale-105"
              >
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                  <Mail className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium">irfanonline37@gmail.com</p>
                </div>
              </a>
              
              <a
                href="tel:+923025849734"
                className="flex items-center gap-4 p-4 glass-card rounded-lg hover:glow-border transition-all duration-300 hover:scale-105"
              >
                <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center">
                  <Phone className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Phone / WhatsApp</p>
                  <p className="font-medium">+92 302 5849734</p>
                </div>
              </a>
              
              <a
                href="https://github.com/irfanonline37"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 glass-card rounded-lg hover:glow-border transition-all duration-300 hover:scale-105"
              >
                <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                  <Github className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">GitHub</p>
                  <p className="font-medium">github.com/irfanonline37</p>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
