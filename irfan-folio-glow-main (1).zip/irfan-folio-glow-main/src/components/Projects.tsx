import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import project1 from "@/assets/project-01.png";
import project2 from "@/assets/project-02.png";
import project3 from "@/assets/project-3.png";
import project4 from "@/assets/project-4.png";
import project5 from "@/assets/project-5.png";
import project6 from "@/assets/project-6.png";

gsap.registerPlugin(ScrollTrigger);

const Projects = () => {
  const projectsRef = useRef<HTMLDivElement>(null);

  const projects = [
    {
      title: "Rug Gallery Store",
      image: project1,
      description: "Premium rug e-commerce with advanced filtering and seamless checkout",
      tags: ["Shopify", "Liquid", "Custom Theme"],
    },
    {
      title: "Salim Rugs",
      image: project2,
      description: "Elegant rug collection showcase with product variants and quick view",
      tags: ["Shopify", "Theme Customization", "SEO"],
    },
    {
      title: "ShopiFit Fitness Store",
      image: project3,
      description: "Modern fitness equipment store with dynamic product displays",
      tags: ["Shopify", "Speed Optimization", "Responsive"],
    },
    {
      title: "MKE Cabinets",
      image: project4,
      description: "Custom cabinet design consultation with interactive galleries",
      tags: ["WordPress", "Elementor", "Custom Design"],
    },
    {
      title: "Cabinets.com",
      image: project5,
      description: "Premium kitchen cabinet showcase with design quote system",
      tags: ["WordPress", "E-commerce", "Lead Generation"],
    },
    {
      title: "Badger Cabinets",
      image: project6,
      description: "Kitchen cabinet store with instant estimate calculator",
      tags: ["WordPress", "Custom Features", "Conversion Optimization"],
    },
  ];

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".project-card", {
        opacity: 0,
        y: 60,
        scale: 0.9,
        duration: 0.8,
        stagger: 0.15,
        ease: "power3.out",
        scrollTrigger: {
          trigger: ".projects-grid",
          start: "top 70%",
        },
      });
    }, projectsRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={projectsRef}
      className="py-20 px-4 relative overflow-hidden"
      id="projects"
    >
      <div className="absolute inset-0 grid-bg opacity-10" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
          <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Featured Projects
          </span>
        </h2>
        
        <div className="projects-grid grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="project-card glass-card rounded-xl overflow-hidden group hover:scale-105 transition-all duration-500 hover:glow-border"
            >
              <div className="relative h-56 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </div>
              
              <div className="p-6 space-y-4">
                <h3 className="text-xl font-bold group-hover:text-primary transition-colors duration-300">
                  {project.title}
                </h3>
                
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="px-3 py-1 text-xs font-medium bg-primary/10 text-primary rounded-full border border-primary/20"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
