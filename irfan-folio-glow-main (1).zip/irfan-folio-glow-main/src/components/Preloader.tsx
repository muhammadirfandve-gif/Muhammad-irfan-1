import { useEffect, useState } from "react";
import { gsap } from "gsap";

const Preloader = ({ onComplete }: { onComplete: () => void }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 1;
      });
    }, 20);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (progress === 100) {
      gsap.to(".preloader", {
        opacity: 0,
        scale: 0.8,
        duration: 0.8,
        ease: "power3.out",
        onComplete: () => {
          onComplete();
        },
      });
    }
  }, [progress, onComplete]);

  return (
    <div className="preloader fixed inset-0 z-50 flex flex-col items-center justify-center bg-background">
      <div className="text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-8 glow-text">
          MUHAMMAD IRFAN
        </h1>
        
        <div className="w-64 h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-200"
            style={{ width: `${progress}%` }}
          />
        </div>
        
        <p className="text-muted-foreground mt-4 text-lg">{progress}%</p>
      </div>
      
      <div className="absolute inset-0 grid-bg opacity-30" />
    </div>
  );
};

export default Preloader;
