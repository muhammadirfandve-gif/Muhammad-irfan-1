import { useState } from "react";
import Preloader from "@/components/Preloader";
import Hero from "@/components/Hero";
import About from "@/components/About";
import TechStack from "@/components/TechStack";
import Projects from "@/components/Projects";
import Reviews from "@/components/Reviews";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

const Index = () => {
  const [loading, setLoading] = useState(true);

  return (
    <>
      {loading && <Preloader onComplete={() => setLoading(false)} />}
      
      <div className={loading ? "hidden" : "block"}>
        <Hero />
        <About />
        <TechStack />
        <Projects />
        <Reviews />
        <Contact />
        <Footer />
      </div>
    </>
  );
};

export default Index;
